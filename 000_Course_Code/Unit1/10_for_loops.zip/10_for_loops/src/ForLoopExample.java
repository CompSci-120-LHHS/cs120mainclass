
import java.util.Scanner;  //Used in example 3

public class ForLoopExample {
    public static void main(String[] args) throws Exception {

        /*---------------------EXAMPLE-1 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        //Example of a simple for loop

        for (int i=0; i <=10; i++){ //loops from i =0 to i = 10, incrementing i by 1
            System.out.printf("Printing Loop #: %d\n", i);
        }

        System.out.println("Finished First Loop!");

        for (int i=10; i >= 0; i--){ //loops from i = 10 to i = 0, decrementing i by 1
            System.out.printf("Printing Loop #: %d\n", i);
        }

        /*---------------------EXAMPLE-1 END -------------------- */


        /*---------------------EXAMPLE-2 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        // //Example of a for..each loop for use if arrays, string and other iterable objects
        // String classList[] = {"Joe", "Sally", "Jim", "June", "Jordan"};

        // int count = 1; //initialized count to 'one' so count starts at 1'st student

        // for (String i : classList){
        //     System.out.printf("%1$d: %2$s is present\n",count, i);  //print sees the value of count incremented from the last loop
        //     count++; //increments the count by 1
        // }

        /*---------------------EXAMPLE-2 END -------------------- */

        /*---------------------EXAMPLE-3 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */
                
        // //Below is an example of a nested for loop
        
        // int sideA;
        // int sideB;

        // Scanner input = new Scanner(System.in);          //takes user input for the dimensions of shape

        // System.out.print("Enter length of side A: ");
        // sideA = input.nextInt();
        // System.out.print("Enter length of side B: ");
        // sideB = input.nextInt();

        // //Draws a square 
        // for (int i=0; i <= sideA; i++){ 
        //     System.out.print("Outer: ");      //first loop handles each row
        //     for(int j=0; j <= sideB; j++){      //second loop handles what is printed in each row 
        //         System.out.print("I ");                            
        //     }            
        //     System.out.println(" ");
        // }

        // System.out.println(" ");

        // //Draws a triangle
        // for (int i=0; i <= sideA; i++){ 
        //     System.out.print("Outer O: ");          
        //     for(int j=0; j <= sideB; j++){
        //         System.out.print("I ");                            
        //     }
        //     sideB--;
        //     System.out.println(" ");
        // }
        // input.close(); 

        /*---------------------EXAMPLE-3 END -------------------- */

      
        

    }
}
