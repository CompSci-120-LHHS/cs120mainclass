public class ArraysExample {
    public static void main(String[] args) throws Exception {

        /*---------------------EXAMPLE-1 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        //Arrays can only hold one data type (int, char, String etc...)
        //Arrays can be declared and assigned values seperately as below:

        int[] grades = new int[5];  //only 5 grades can fit in this array       

        grades[0] = 2;
        grades[1] = 4; //assigns the first two values

        System.out.println(grades); //prints only the memory address of the array object
        System.out.println(grades[1]); //must address
        System.out.println(grades[2]); //empty slot in array returns '0'

        String[] names = {"Jeff", "Abed", "Brita", "Annie"}; //array values can be declared all at once
        System.out.println(names[1]);

        names[1] = "Troy"; //values can be addressed and re-assigned
        System.out.println(names[1]);

         /*---------------------EXAMPLE-1 END -------------------- */



        /*---------------------EXAMPLE-2 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        // //Arrays can Looped over in two ways using for loops   

        // String[] names = {"Jeff", "Abed", "Brita", "Annie"};

        // //Method 1:
        // System.out.println("Method #1: ");
        // for (int i=0; i < names.length; i++){    //using the 'length' attribute
        //     System.out.println(names[i]);
        // }
        
        // System.out.println("----------------");

        // //Method 2:
        // System.out.println("Method #2: ");
        // for (String name : names){
        //     System.out.println(name);
        // }

         /*---------------------EXAMPLE-2 END -------------------- */


        /*---------------------EXAMPLE-3 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        // //Arrays can more than 1 dimensions - matrixes used from bitmap 
        // //images used 2D arrays for example to encode image data

        // char[][] image1 = {
        //     {' ',' ','O',' ',' '},
        //     {' ',' ','O',' ',' '},
        //     {' ',' ','O',' ',' '},
        //     {' ',' ','O',' ',' '},
        //     {' ',' ','O',' ',' '},
        // };

        // for (char[] row:image1){
        //     System.out.println(row);                
        //     }

        // System.out.println(); //make a space between shapes

        // char[][] image2 = {
        //     {' ','O',' ','O',' '},
        //     {'O',' ','O',' ','O'},
        //     {'O',' ',' ',' ','O'},
        //     {' ','O',' ','O',' '},
        //     {' ',' ','O',' ',' '},
        // };

        // for (char[] row:image2){
        //     System.out.println(row);                
        //     }
        
        // System.out.println(); //make a space between shapes

        // char[][] image3 = {
        //     {'*','*',' ','*','*'},
        //     {'*',' ',' ','*',' '},
        //     {'*',' ',' ',' ','*'},
        //     {'*',' ',' ',' ','*'},
        //     {'*','*',' ','*','*'},
        // };

        // for (char[] row:image3){
        //     System.out.println(row);                
        //     }
    
        /*---------------------EXAMPLE-3 END -------------------- */

        
    }
}
