import java.io.File;
import java.io.FileNotFoundException;
import java.util.Formatter;


public class WriteToText {
    public static void main(String[] args) throws FileNotFoundException {
        String firstName = "Jeff";
        String lastName = "McDowell";
        String role = "Teacher";
        String languages[] = {"java", "python", "c++", "php", "javascript"};
        String schoolName = "Leo Hayes High School";

        File outputText = new File("src/output.txt");
        try{ //try to write to file
            Formatter text = new Formatter(outputText);
            text.format("%1$s %2$s is a %3$s at %4$s who enjoys programming %6$s and %5$s", firstName, lastName, role, schoolName, languages[0], languages[1]);
            System.out.println("New txt file has been written!");
            text.close();
        }catch (FileNotFoundException ex){
            ex.getStackTrace();
        }    

    }
}
