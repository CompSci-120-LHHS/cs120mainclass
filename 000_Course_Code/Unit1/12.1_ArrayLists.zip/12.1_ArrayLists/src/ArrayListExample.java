import java.util.ArrayList;  //this package must be imported to use the arraylist functionality
import java.util.Arrays;

public class ArrayListExample {
    public static void main(String[] args) throws Exception {

        /*---------------------EXAMPLE-1 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        //arraylist are resizable, iterable and mutable. But they store only one datatype
        ArrayList<String> shipNames = new ArrayList<String>();  //declared without variables assigned, <String> is the type wrapper class, can also be Integer, Double etc...

        shipNames.add("Heart of Gold");
        shipNames.add("Black Pearl");
        shipNames.add("In Amber Clad");
        shipNames.add("Thunder Child");

        System.out.println(shipNames);  //returns the values wrapped in [] 

        //indexing items uses the .get() method ....not the [] notation used for regular arrays
        System.out.println(shipNames.get(2));
        
        //Changing values used the .set() method
        shipNames.set(2,"Forward Unto Dawn");
        System.out.println(shipNames.get(2));

        //other useful methods used with array lists are:

        int sizeOfArrayList = shipNames.size(); //useful when looping through arraylists
        System.out.printf("Number of elements in the ArrayList: %d\n", sizeOfArrayList);

        shipNames.clear();                      //clears the arraylist contents
        sizeOfArrayList = shipNames.size();
        System.out.printf("Number of elements in the ArrayList: %d\n", sizeOfArrayList);

        /*---------------------EXAMPLE-1 END -------------------- */



        /*---------------------EXAMPLE-2 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        // //Looping through arraylist is the same as usual arrays
        // ArrayList<String> names = new ArrayList<>(Arrays.asList("Jeff", "Abed", "Brita", "Annie"));

        // System.out.println(names.size());       

        // //Method 1:
        // System.out.println("Method #1: ");
        // for (int i=0; i < names.size(); i++){    //using the 'length' attribute
        //     System.out.println(names.get(i));
        // }
        
        // System.out.println("----------------");

        // //dynamically add a new element to the end of the array list
        // names.add(2,"Pierce"); //inserts 'Pierce' into position 2 and shifts array list back

        // //Method 2:
        // System.out.println("Method #2: ");
        // for (String name : names){
        //     System.out.println(name);
        // }

        /*---------------------EXAMPLE-2 END -------------------- */

    }
}
