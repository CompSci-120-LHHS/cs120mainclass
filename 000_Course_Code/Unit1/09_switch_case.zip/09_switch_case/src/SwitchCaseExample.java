public class SwitchCaseExample {
    public static void main(String[] args) throws Exception {
        
        char letter = 'a';

        switch (letter) {
            case 'a', 'b', 'c':
                System.out.println("2");                
                break;
            case 'd', 'e', 'f':
                System.out.println("3");                
                break;
            case 'g', 'h', 'i':
                System.out.println("4");                
                break;
            case 'j', 'k', 'l':
                System.out.println("5");                
                break;
            case 'm', 'n', 'o':
                System.out.println("6");                
                break;
            case 'p', 'q', 'r', 's':
                System.out.println("7");                
                break;
            case 't', 'u', 'v':
                System.out.println("8");                
                break;
            case 'w', 'x', 'y', 'z':
                System.out.println("9");                
                break;
            default:
                System.out.println("Not a valid input");
                break;
        }

    }
}







