public class BooleanExamples {
    public static void main(String[] args) throws Exception {

        /*---------------------EXAMPLE-1 START -------------------- */
        int a = 5;
        int b = 3;
        int c = 5;
        String item1 = "apples";
        String item2 = "oranges";

        //Using comparison operators
        System.out.println(a > b); // returns true, because 5 is higher than 3
        System.out.println(a >= c); // returns true, because 5 equals 5
        System.out.println(a == c); // returns true, because 5 equals 5
        System.out.println(item1 == item2); // returns false because strings are not the same
        //alternatively, using the equals() method
        System.out.println(item1.equals(item2)); // returns false because strings are not the same


        //Using Logic Operators
        System.out.println(a >= c && a == c); // AND operator: returns true, both conditions are true
        System.out.println(a < c || a == c); //  OR operator: returns true, because a==c 
        System.out.println(!(a < c || a == c)); //  NOT operator: returns false, because !  

        /*---------------------EXAMPLE-1 END -------------------- */

        /*---------------------EXAMPLE-2 START -------------------- */
        //Using booleans in If...Else statements

        int x = 5;
        int y = 3;
        String item3 = "apples";
        String item4 = "oranges";        

        if (x == y){
            System.out.println("This is A TRUE Statement");
        }else if((x < y)){
            System.out.println("This is A TRUE Statement");
        }else if((x > y)){
            System.out.println("This is A TRUE Statement");
        }
        else{
            System.out.println("This is A FALSE Statement");
        }
        
        if (item3.equals(item4)){
            System.out.println("This is A TRUE Statement");
        }else{
            System.out.println("This is A FALSE Statement");
        }

        /*---------------------EXAMPLE-2 END -------------------- */

        /*---------------------EXAMPLE-3 START -------------------- */
        //Using booleans in While Loop

        int i = 0;
        boolean status = false;

        //Has the loop repeated 20 times?
        while (status == false){
            if (i == 19){
                status = true;
                System.out.println("Loop iteration: " + (i+1) + " ...All Done!");
            }else{
                status = false;
                System.out.println("Loop iteration: " + (i+1) + " ...Loop Again");
                i++;
            }
        }

        /*---------------------EXAMPLE-3 END -------------------- */

    }
}
