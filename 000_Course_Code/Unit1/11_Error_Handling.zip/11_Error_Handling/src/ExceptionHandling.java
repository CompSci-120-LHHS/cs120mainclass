import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.File;

public class ExceptionHandling {
    public static void main(String[] args) throws Exception {
       
        /*---------------------EXAMPLE-1 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        // //First Loop
        // for (int i=0; i <=10; i+=2){ //loops from i =0 to i = 10, incrementing i by 2
        //     System.out.printf("Printing Loop #: %d\n", i);
        // }
        // System.out.println("Finished First Loop!");

        
        // //Second Loop
        // //There is a syntax error in this next loop, try...catch can handle this error without breaking the code    
        // try {
        //     for (int i=10; i >= 0; i--){ 
        //         System.out.printf("Printing Loop #: %1\n", i);
        //     } 

        // }catch (Exception e) {  // e is the variable name we give to the error, it can be anything, but 'e' is convension
        //     System.out.println("-----------------------\nHmmm....Second Loop Threw An Error!");
        //     System.out.println(e.fillInStackTrace()+"\n-----------------------"); //There are a few built in methods for returning info about the error 'fillInStackTrace' is usually informative
        // }finally{
        //     //This block executes not matter what
        //     //Third Loop
        //     for (int i=10; i >=0; i-=2){ //loops from i =0 to i = 10, incrementing i by 2
        //         System.out.printf("Printing Loop #: %d\n", i);
        //     }
        //     System.out.println("Finished Third Loop!");    
        // }       
            

        /*---------------------EXAMPLE-1 END -------------------- */





        /*---------------------EXAMPLE-2 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */
        
        // //try{}...catch{} used to handle error if input.txt file does not exist. 'throws Exceptions' is declared in the main method
        // //If another Exceptions library is used (i.e. FileNotFoundException), replace 'Exception' with 'FileNotFoundException'
        // String firstline;
        // String secondline;
        // String thirdline;

        
        // try{   
        //     File inputFile = new File("src/input.txt");        
        //     Scanner input = new Scanner(inputFile);

        //     firstline = input.nextLine();
        //     System.out.println(firstline);

        //     secondline = input.nextLine();
        //     System.out.println(secondline);

        //     thirdline = input.nextLine();
        //     System.out.println(thirdline);
        //     input.close();

        // }catch(Exception e){
        //     System.out.println("-----------------------\nHmmm....There was an error getting your file! Here are the deets:");
        //     System.out.println(e.fillInStackTrace()+"\n-----------------------");
        // }
        
        /*---------------------EXAMPLE-2 END -------------------- */





        /*---------------------EXAMPLE-3 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */
        
        // //try...catch...finally blocks: Used as a final output option after try and catch and runs without condition at the end
        // //There is still and error below, but the finally block will still run
        // String firstline;
        // String secondline;
        // String thirdline;
        
        // try{   
        //     File inputFile = new File("src/input.txt");        
        //     Scanner input = new Scanner(inputFile);

        //     firstline = input.nextLine();
        //     System.out.println(firstline);

        //     secondline = input.nextLine();
        //     System.out.println(secondline);

        //     thirdline = input.nextLine();
        //     System.out.println(thirdline);
        //     input.close();

        // }catch(Exception e){
        //     System.out.println("-----------------------\nHmmm....There was an error getting your file! Here are the deets:");
        //     System.out.println(e.fillInStackTrace()+"\n-----------------------");
        // }finally{
        //     System.out.println("In the \"finally\" block: try and catch are done...There's still and error somewhere!\n");
        // }
        
        /*---------------------EXAMPLE-3 END -------------------- */


        /*---------------------EXAMPLE-4 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        int num1;
        int num2;
        int sum;
        boolean status = true;

               
        
        while(status){
            try{
                Scanner input = new Scanner(System.in); 
                System.out.print("Enter First Integer: ");
                num1 = input.nextInt();
                System.out.print("Enter Second Integer: ");
                num2 = input.nextInt();
                sum = num1 + num2;
                System.out.printf("The sum of your inputs is: %1\n", sum);
                status = false;
                input.close();      
    
            }catch(InputMismatchException error){
                System.out.println("\n---------------------ERROR!------------------------");
                System.out.println("Wrong variable type, please reenter Integer Values!");
                System.out.println("---------------------------------------------------");
                status = true;                            
            }catch(Exception error){
                System.out.println("\n---------------------ERROR!------------------------");
                error.printStackTrace();
                System.out.println("---------------------------------------------------");

            }
        }        
        


        /*---------------------EXAMPLE-4 END -------------------- */


    }
}
