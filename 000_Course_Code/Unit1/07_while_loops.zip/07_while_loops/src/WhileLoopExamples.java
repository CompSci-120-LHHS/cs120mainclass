public class WhileLoopExamples {
    public static void main(String[] args) throws Exception {     
        
        int lowerbound = 1;
        int upperbound = 1000;
        int sum = 0;
        int number = lowerbound; //current number in the count

        //use while loop to sum each number together from lowerbound to upperbound
        while(number <= upperbound){
            sum = sum + number;
            number++;
        }
        System.out.printf("The sum from %1$d to %2$d is %3$d", lowerbound, upperbound, sum);
    }
}


//CHALLENGE QUESTIONS
/* --------------------------------------------------------------------------------------------------------------------------
(1) Refactor the above code to use the 'for loop' and 'do...while' loop
-------------------------------------------------------------------------------------------------------------------------*/
/* --------------------------------------------------------------------------------------------------------------------------
(2) Modify the above program (slide 3) to sum all the numbers from 9 to 888. (Ans: 394680)
-------------------------------------------------------------------------------------------------------------------------*/
/* --------------------------------------------------------------------------------------------------------------------------
(3) Modify the above program (slide 3) to sum all the odd numbers between 1 to 1000.
(Hint: Change the post-processing statement to "number = number + 2". Ans: 250000)
-------------------------------------------------------------------------------------------------------------------------*/
/* --------------------------------------------------------------------------------------------------------------------------
(4) Modify the above program (slide 3) to sum all the numbers between 1 to 1000 that are divisible by 7.
(Hint: Modify the initialization and post-processing statements. Ans: 71071)
-------------------------------------------------------------------------------------------------------------------------*/
/* --------------------------------------------------------------------------------------------------------------------------
(5) Modify the above program (slide 3) to find the sum of the square of all the numbers from 1 to 100, i.e. 1*1 + 2*2 + 3*3 +... (Ans: 338350)
-------------------------------------------------------------------------------------------------------------------------*/
/* --------------------------------------------------------------------------------------------------------------------------
(7) Modify the above program (called RunningNumberProduct) to compute the product of all the numbers from 1 to 10.
(Hint: Use a variable called product instead of sum and initialize product to 1. Ans: 3628800)
-------------------------------------------------------------------------------------------------------------------------*/