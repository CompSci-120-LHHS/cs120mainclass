
import java.util.HashMap;

public class HashMapExample {
    public static void main(String[] args) throws Exception {
        
        /*---------------------EXAMPLE-1 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        //Hashmaps work with 'key/value' pairs like a dictionary
        HashMap<String, Integer> weatherConditions = new HashMap<String, Integer>();
        
        weatherConditions.put("Fredericton",10);
        weatherConditions.put("Moncton",2);
        weatherConditions.put("Saint John",11);
        weatherConditions.put("Sussex",5);

        System.out.println(weatherConditions);
        System.out.println(weatherConditions.size());

        //Addressing values in HashMaps using .get method and key value:
        System.out.printf("The temperature in Moncton is current %d degC\n", weatherConditions.get("Moncton"));

        for (String city: weatherConditions.keySet()){  //use values() method to get the values instead of keys
            System.out.println(city);
        }
        

        /*---------------------EXAMPLE-1 END -------------------- */





    }
}
