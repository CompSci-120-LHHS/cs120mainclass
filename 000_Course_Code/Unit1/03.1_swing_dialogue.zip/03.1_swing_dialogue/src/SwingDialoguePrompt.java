import javax.swing.JOptionPane;

public class SwingDialoguePrompt {
    public static void main(String[] args) throws Exception {
        String radiusInputStr;
        Double radius, area;
        //Read input string from dialog box
        radiusInputStr = JOptionPane.showInputDialog("Enter radius of the circle: ");
        radius = Double.parseDouble(radiusInputStr); //Converts string to double
        area = Math.pow(radius, 2)*Math.PI;
        System.out.println("The area is: " + area);    
    }
}
