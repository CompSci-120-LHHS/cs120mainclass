import java.util.*;

public class EnumExample {
    public static void main(String[] args) throws Exception {
        
        /*---------------------EXAMPLE-1 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        //Enums are a type of class (more on this later), that list constants and are often used in
        //combination with switch cases:

        enum MachineState{INITIALIZE, RUN, STOP, DEBUG};
        MachineState myMachineState = MachineState.INITIALIZE;  //Try uncommenting another value of myMachineState
        // myMachineState = MachineState.RUN; 
        // myMachineState = MachineState.STOP; 
        // myMachineState = MachineState.DEBUG;   

        switch (myMachineState){
            case INITIALIZE:
            System.out.println("In INITIALIZE case");
            break;
            case RUN:
            System.out.println("In RUN case");
            break;
            case STOP:
            System.out.println("In STOP case");
            break;
            case DEBUG:
            System.out.println("In DEBUG case");
            break;
        }

        /*---------------------EXAMPLE-1 END -------------------- */
        
        
        
        /*---------------------EXAMPLE-2 START -------------------- */
        /*--------------UNCOMMENT TO RUN CODE (Ctrl+/)------------- */

        // //Enums are a type of class (more on this later), that list constants and are often used in
        // //combination with switch cases:

        // enum MachineState{INITIALIZE, RUN, STOP, DEBUG};
        // MachineState myMachineState = MachineState.INITIALIZE;

        // Scanner input = new Scanner(System.in);
        // int userInput;
        // String submenuSelect;

        // while (myMachineState != MachineState.STOP){
        //     switch (myMachineState){
        //         case INITIALIZE:
        //             System.out.println("Select # From Options To Begin:\n------------------------\n");
        //             System.out.println("1: RUN Machine");
        //             System.out.println("2: DEBUG Machine");
        //             System.out.println("3: STOP Machine");
        //             System.out.print("COMMAND: ");
        //             userInput = input.nextInt();
        //             if (userInput == 1) {
        //                 myMachineState = MachineState.RUN;  
        //             } else if(userInput == 2){
        //                 myMachineState = MachineState.DEBUG;
        //             } else if(userInput == 3){
        //                 System.out.println("Shutting Down...Goodbye");
        //                 myMachineState = MachineState.STOP;  
        //             }else{
        //                 System.out.println("Incorrect Entry, Please Try Again");
        //             } 
        //             break;
        //         case RUN:
        //             System.out.print("The Machine is running. Would you like to stop? Y/N: ");
        //             submenuSelect = input.next();                                       
        //             if (submenuSelect.equals("Y")){
        //                 myMachineState = MachineState.INITIALIZE;
        //                 System.out.println("Returning to Main Menu"); 
        //             }else{
        //                 System.out.println("OK, Machine Still Running...");
        //             }
        //             break;
        //         case DEBUG:
        //             System.out.print("Machine In Factory Mode! Type Y to exit: ");
        //             submenuSelect = input.next();                    
        //             if (submenuSelect.equals("Y")){
        //                 myMachineState = MachineState.INITIALIZE;
        //             }else{
        //                 System.out.println("Debug mode still active...");
        //             }
        //             break;
        //         case STOP:
        //             System.out.println("Shutting Down...Goodbye");
        //             break;                    
                
        //     }
        // }
        // input.close(); 

        /*---------------------EXAMPLE-2 END -------------------- */
    }
}
