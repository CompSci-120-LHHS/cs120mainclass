package Transportation;
import java.util.concurrent.TimeUnit;

public class Vehicle {

    public String model;
    public String make;
    public int year;

    //constructor
    public Vehicle(String model, String make, int year){
        this.model = model;
        this.make = make;
        this.year = year;
    }

    public String fullTank(){
        String TankLevel = "Full";
        return TankLevel; 
    }

    public String halfTank(){
        String TankLevel = "Half";
        return TankLevel; 

    }
    
    //Method refuel accepting String argument
    public void refuel(String TankLevel){        
        System.out.print("Refueling ");
        for (int i = 0; i < 10; i++){
            System.out.print(". ");
            try{
                TimeUnit.SECONDS.sleep(1);
            }catch(Exception e){
                System.out.println(e.fillInStackTrace());
            }
        }
        System.out.printf("Gas Tank Is Now: %s\n", TankLevel);        
    }

    //Overloaded refuel method accepting int argument
    public void refuel(int TankLevel){
        System.out.print("Refueling ");
        for (int i = 0; i < 10; i++){
            System.out.print(". ");
            try{
                TimeUnit.SECONDS.sleep(1);
            }catch(Exception e){
                System.out.println(e.fillInStackTrace());
            }
        }
        System.out.printf("Gas Tank Is Now: %d\n", TankLevel);
    }

}
