package Transportation;

public class Plane extends Vehicle{
    int range;

    //constructor
    public Plane(String model, String make, int year, int range){
        super(model, make, year);
        this.range = range;
    }

}
