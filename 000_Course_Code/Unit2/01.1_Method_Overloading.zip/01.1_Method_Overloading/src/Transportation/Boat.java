package Transportation;

public class Boat extends Vehicle{
    String powerType;

    public Boat(String model, String make, int year, String powerType){
        super(model, make, year);
        this.powerType = powerType;
    }

}
