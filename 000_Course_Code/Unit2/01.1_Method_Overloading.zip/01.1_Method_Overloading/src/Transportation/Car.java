package Transportation;

public class Car extends Vehicle{
    String powerType;

    public Car(String model, String make, int year, String powerType){
        super(model, make, year);
        this.powerType = powerType;
    }

}
