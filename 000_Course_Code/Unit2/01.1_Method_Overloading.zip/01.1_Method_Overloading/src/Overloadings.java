import Transportation.*;

public class Overloadings {
    public static void main(String[] args) throws Exception {

        //create an instance of Plane
        Plane plane1 = new Plane("J50 Twin Bonanza", "Beechcraft", 1963, 2660);
        
        
        plane1.refuel("Full"); //refuel and fill tank 'Full'
        plane1.refuel(80); //refuel and fill tank '80', meaning 80%  

    }
}
