package One;

public class Alpha {
    private int myKey = 123;
    protected int myProtectedVar = 456;
    public int myPublicVar = 789;
    
    private void myPrivateMethod(){
        System.out.println("in private method");
    }

    private boolean isEqualTo(Alpha anotherAlpha){
        if (this.myKey == anotherAlpha.myKey)
            return true;
        else
            return false;
    }

    public void compareTo(Alpha anotherAlpha){
        if(isEqualTo(anotherAlpha)){
            System.out.println("These instances have equal keys");
            myPrivateMethod();
        }else{
            System.out.println("Keys not equal!");
        }
    }

    public void set_myKey(int key){
        this.myKey = key;
    }

}
