package One;

public class Gamma {
    private String myKey = "abc";
    protected String myProtectedVar = "efg";
    public String myPublicVar = "hij";

    //I can create an instance of Alpha in Gamma

    Gamma gamma1 = new Gamma();
    String myKeyGamma = gamma1.myKey;

    Alpha alpha1 = new Alpha();
    //int myKeyAlpha = alpha1.myKey;  //This Does not work because myKey is 'Private' and 'not visible' from Gamma
    int protectedAlpha = alpha1.myProtectedVar; //This works because it is 'protected' and shared in between classes in same package
    int publicAlpha = alpha1.myPublicVar; //This works because it is 'public', everything can see

}
