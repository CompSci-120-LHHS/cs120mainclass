package Two;
public class Delta {
    protected int areaCodeDelta = 800;

    protected void message(){
        System.out.println("Hello From Delta");
    }

    Delta delta1 = new Delta();
    Beta beta1 = new Beta();

    int betaCode = beta1.areaCodeBeta;
    int betaVar = beta1.specialVar; 


}
