
package Two;
import One.*;

public class Beta extends Alpha{
    protected int areaCodeBeta = 506;
    public int specialVar = 2;

    protected void message(){
        System.out.println("Hello From Beta");
    }

    Alpha alpha1 = new Alpha();
    int alphaProtected = alpha1.myPublicVar; //This works because Beta is a subclass of Alpha
    Beta beta1 = new Beta();
}
