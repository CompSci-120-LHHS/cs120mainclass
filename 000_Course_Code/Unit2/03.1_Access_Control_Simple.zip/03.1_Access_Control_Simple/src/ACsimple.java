import One.*;

class ACsimple{

    public static void main(String[] args){

        //Looking at private members, create two instances of the class Alpha
        
        Alpha alpha1 = new Alpha();
        alpha1.set_myKey(1234); //public method can set a private variable (but cannot set directly via alpha1.myKey)
        
        Alpha alpha2 = new Alpha();
        alpha2.set_myKey(1234);

        //Run a public method that calls two private methods belonging to class Alpha type only
        alpha1.compareTo(alpha2); //print "These instances have equal keys" and "in private method"

    }

}