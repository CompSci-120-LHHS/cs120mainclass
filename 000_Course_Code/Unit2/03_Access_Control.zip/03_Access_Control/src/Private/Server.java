package Private;

import java.util.concurrent.TimeUnit;

public class Server {
    private static String serverLoc = "Toronto";
    protected static String serverName = "GlaDos";

    public void selfDestruct(){
        System.out.print("Self Destruct Initiated. Detontation in ");
        for(int i = 5; i > 0; i--){
            System.out.printf("%d ", i);
            try{
                TimeUnit.SECONDS.sleep(1);
            }catch (Exception e){
                System.out.println(e.fillInStackTrace());
            }            
        }
        System.out.println("... BOOM");  

    }

}


