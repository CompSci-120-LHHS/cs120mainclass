package Private;

public class Session {
    
    //instance variables
    private String usrCheck = "user123";
    private String pwdCheck = "password123";
    
    private String usr;
    private String pwd; 

    private String phone;
    private String email = "usr" + "@nbed.nb.ca";
    protected String employer = "nbed";
    protected String role = "teacher";
    
    public String province = "NB"; 
    
    //constructor
    public Session(String usr, String pwd){
        this.usr = usr;
        this.pwd = pwd;
        System.out.println("Session Created!");    
    }

    public int login(){
        if(usrCheck.equals(this.usr) && pwdCheck.equals(this.pwd)){
            System.out.printf("Login Success, welcome %s\n", this.usr);
            return 0;
        }else{
            System.out.println("Incorrect Credentials");
            return 1;
        }
    }

    public void set_phone(String phone){
        this.phone = phone;
        System.out.println("Phone Number Added");

    }

    public String get_phone(){
        return this.phone;
    }

    public String get_email(){
        return this.email;
    }
}

