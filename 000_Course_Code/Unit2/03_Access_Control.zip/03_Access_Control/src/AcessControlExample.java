
import Private.*;
import Public.*;
import java.time.*;
import java.util.Scanner;

public class AcessControlExample {
    public static void main(String[] args) throws Exception {
        
        Scanner input = new Scanner(System.in);
        System.out.println("Login To Secure Server: ");
        System.out.print("Enter Username: ");
        String username = input.next();
        System.out.print("Enter Password: ");
        String password = input.next();

        Session mySession = new Session(username, password);
        mySession.login();
        System.out.printf("Server has been live for %1$d days since %2$s\n",SystemInfo.currentRuntime(LocalDate.now()),SystemInfo.firstDay.toString());

        
        Server server1 = new Server();
        PublicServer server2 = new PublicServer();
        System.out.print("Self Destruct? Y/N: ");
        String sd = input.next();
        if(sd.equals("Y")){
            server1.selfDestruct();           
        }else{
            System.out.println("Self Destruct Terminated");
        }

        input.close();
    }
}
