package Public;

import Private.Server;

public class PublicServer extends Server{
    
    public static void stnMessage(){
        System.out.println("Hello, You're Doing Great!");
    }

}
