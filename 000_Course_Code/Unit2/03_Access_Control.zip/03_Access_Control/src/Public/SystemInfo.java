package Public;

import java.time.*;
import java.time.temporal.ChronoUnit;

public class SystemInfo {

    public static LocalDate firstDay = LocalDate.of(2024, 2, 1);
    public static LocalDate lastDay = LocalDate.of(2024, 06, 25); 
    
    public static int currentRuntime(LocalDate today){
        int runtime;
        runtime = (int) firstDay.until(today, ChronoUnit.DAYS);
        return runtime;
    }
    
    public static int timeRemaining(LocalDate today){
        int remaining;
        remaining = (int) today.until(lastDay, ChronoUnit.DAYS);
        return remaining;
    }

}
