import java.util.*;

public class MethodExamples {

    //Functions
    public static double circArea(double r){
        double area = Math.PI * Math.pow(r, 2);
        return area;
    }

    public static double circVol(double r){
        double volume = (4/3)*Math.PI*Math.pow(r, 3);
        return volume; 
    }

    public static void main(String[] args) throws Exception {
        double radius;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the radius: ");
        radius = input.nextDouble();
        System.out.printf("Calculated Area of Sphere Is: %.2f\n", circArea(radius));
        System.out.printf("Calculated Volume of the Sphere Is: %.2f\n", circVol(radius));
        input.close();
    }
}
