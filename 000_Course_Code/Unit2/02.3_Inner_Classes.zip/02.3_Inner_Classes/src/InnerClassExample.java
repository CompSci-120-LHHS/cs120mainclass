public class InnerClassExample {
    public static void main(String[] args) throws Exception {

        String guestName = "Friends";
        
        //Callable from this class without an instance
        OuterClass.InnerClass.printMsg(guestName);
        //method gets on String from the OuterClass
        //and one from InnerClassExample
    }
}
