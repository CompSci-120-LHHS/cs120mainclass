public class OuterClass {

    static String username = "Jeff";

    public class InnerClass{
        //Created an static method callable without creating instance, has acces to OuterClass's username var
        public static void printMsg(String guestName){
            System.out.printf("Hello %1$s and %2$s, Welcome To The Inner Class\n", username, guestName);
        }
    }

}
