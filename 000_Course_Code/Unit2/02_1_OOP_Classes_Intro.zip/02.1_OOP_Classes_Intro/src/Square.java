
public class Square {
    //instance variables
    private double sideLength = 12; //These are default values
    private String colour = "red";

    public Square(){} //empty constructure, instance will have default values
    public Square(double sideLength){
        this.sideLength = sideLength;
    }

    //getter and setter methods
    public void setLength(double sideLength){
        this.sideLength = sideLength;  //sets sideLength to value
    }

    public double getLength(){
        return this.sideLength; //gets sideLength value
    }

    //methods
    public double getPerimeter(){
        return sideLength*4;
    }

    public double getArea(){
        return Math.pow(sideLength, 2); 
    }
}
