public class SquareExample {
    public static void main(String[] args) throws Exception {
        Square square1 = new Square(); //create an instance of the Square class, square1
        Square square2 = new Square(3); //create an instance of the Square class, s2

        //print the information about square1:
        System.out.println("Square square1:");
        //call the getPerimeter() method that we wrote in Square.java:
        System.out.println("perimeter = " + square1.getPerimeter()); 
        //call the getArea() method that we wrote in Square.java:
        System.out.println("area = " + square1.getArea());
        
        //print the information about square2:
        System.out.println("Square square2:");
        System.out.println("perimeter = " + square2.getPerimeter()); 
        System.out.println("area = " + square2.getArea());    
    }
}
