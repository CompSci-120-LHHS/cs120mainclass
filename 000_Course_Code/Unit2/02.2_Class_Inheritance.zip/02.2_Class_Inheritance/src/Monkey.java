public class Monkey {

    //COMPLETE THE CODE...

    //Add type variable    
    //Add swingFromTree() method -> Returns "this.name " + "is swinging from a tree"

}
