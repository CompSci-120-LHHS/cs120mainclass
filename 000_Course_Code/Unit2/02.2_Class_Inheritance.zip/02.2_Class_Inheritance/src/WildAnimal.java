public abstract class WildAnimal {

    //COMPLETE THE CODE...

    //Add habitat variable
    //Add location variable
    //Add play() method -> Returns "this.name " + "is playing"
}
