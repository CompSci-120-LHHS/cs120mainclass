public class Cat {

    //COMPLETE THE CODE...

    //Add breed variable
    //Add purr() method -> Returns "this.name " + " is purring"
    //Add hiss() method -> Returns "this.name " + " is hissing"

}
