public abstract class Pet extends Animal{
    public String ownersName;

    public Pet(int ageIn,
               String sexIn,
               double weightIn,
               String nameIn,
               String ownersNameIn){
                 
        super(ageIn, sexIn, weightIn, nameIn); 
        this.ownersName = ownersNameIn; 
    } 
    public void play(){ 
        System.out.println(name + " is playing with " + ownersName + 
          "!"); 
    }
}
