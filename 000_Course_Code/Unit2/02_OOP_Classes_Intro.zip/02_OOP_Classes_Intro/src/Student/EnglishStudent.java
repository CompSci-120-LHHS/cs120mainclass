package Student;

public class EnglishStudent extends StudentClass{

    String currentReading;

    public EnglishStudent(String first_name, String last_name, String id, String currentReading){
        super(first_name, last_name, id);
        this.currentReading = currentReading;
    }

}
