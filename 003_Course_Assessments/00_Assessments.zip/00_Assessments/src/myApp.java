//Lets Try to add some numbers
public class myApp {
    public static void main(String[] args) throws Exception {
        int number1 = 11;  //declares and assigns an int value
        int number2 = 22;
        int number3 = 23;
        int number4 = 44;
        int number5 = 55;

        int sum; //Declares a variable int without assigning a literal value
        sum = number1 + number2 + number3 + number4 + number5;

        System.out.print("The Sum is: ");
        System.out.println(sum);
        
        
    }
}

/*
CHALLENGE: Write a java program that computes the Area and Circumference of Circle with r = 7
Where A = pi * r**2  and C = 2*pi*r
print the following message to the screen:
The Radius is: 
The area is: 
The circumference is:
*/
